# License

## PRUNE

This Work was prepared by a United States Government employee and, therefore, is excluded from copyright by Section 105 of the Copyright Act of 1976.

Copyright and Related Rights in the Work worldwide are waived through the [CC0 1.0 Universal license](https://creativecommons.org/publicdomain/zero/1.0/).

## Third-Party Libraries

PRUNE uses the following third-party libraries with the following licenses:

* [Json.NET](https://github.com/JamesNK/Newtonsoft.Json) is licensed under the MIT license.
* [Microsoft.Diagnostics.Tracing.TraceEvent Library](https://github.com/Microsoft/perfview/blob/master/documentation/TraceEvent/TraceEventLibrary.md) is licensed under the MIT license.
